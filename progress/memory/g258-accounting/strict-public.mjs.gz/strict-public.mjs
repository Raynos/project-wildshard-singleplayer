import { writeFileSync } from 'node:fs';
import { browserPool } from '/Users/raynos/projects/games/wildshard-singleplayer/scripts/parity/pool.mjs';
import { saveFixture } from '/Users/raynos/projects/games/wildshard-singleplayer/scripts/debug-settings.mjs';
import { GL_INIT } from '/Users/raynos/projects/games/wildshard-singleplayer/scripts/parity/glbytes.mjs';
import { publicGridIntentCode, readPublicGridWitness, publicGridWitnessFailures } from '/Users/raynos/projects/games/wildshard-singleplayer/scripts/public-grid.mjs';
import { stageFloorGrid, driveFloorGrid, gridFloorDocumentIdentity, gridFloorWitnessFailures } from '/Users/raynos/projects/games/wildshard-singleplayer/scripts/frame-floor-grid.mjs';
const root='/Users/raynos/projects/games/wildshard-singleplayer',base=process.argv[2],out=process.argv[3],arm=process.argv[4]??'pine-nalati',tex=process.argv[5]??'auto';
const report={base,arm,device:'iPhone 16 Pro',developer:false,memorySaver:'off',strict:true,texture:tex,routes:[],snapshots:[],errors:[]};const save=()=>writeFileSync(out,JSON.stringify(report,null,2)+'\n');
const pool=browserPool(root,1,'metal');let context,page;
try{
 const browser=await pool.browser(0);context=await browser.newContext({viewport:{width:402,height:874},deviceScaleFactor:3,isMobile:true,hasTouch:true});
 for(const f of [{scope:'device',key:'devMode',data:false},{scope:'global',key:'settings',data:{tier:'phone',volume:0,fps:'auto',tex,memorySaver:'off'},merge:true},{scope:'global',key:'gfx',data:{dpr:'2',aa:'auto'}}])await saveFixture(context,f);
 await context.addInitScript(GL_INIT+';'+publicGridIntentCode({instance:'driftwood-isle',slug:'driftwood-isle'})+';window.__wildshardHarness={seed:357,capture:null};');
 page=await context.newPage();page.on('pageerror',e=>report.errors.push(String(e)));await page.route('**/api/**',r=>r.fulfill({status:200,body:'{}'}));await page.goto(base);report.version=await page.evaluate(()=>fetch('/version.json').then(r=>r.json()));
 await page.locator('.ws-main-select').click();await page.locator('.ws-menu-play').click();await page.waitForFunction(()=>window.__wildshard?.shard?.grid?.state().live?.live?.gameplayReady&&window.__wildshard.world.game.app.state==='play',{}, {timeout:240000});
 await page.evaluate(()=>{window.__wildshard.world.hud.enterNow();window.__g258FrameCallback=null;window.__wildshard.world.game.watchFrames(dt=>window.__g258FrameCallback?.(dt));window.__g258WatchFrames=fn=>{window.__g258FrameCallback=fn;return()=>{if(window.__g258FrameCallback===fn)window.__g258FrameCallback=null;};};});
 const identity=await page.evaluate(gridFloorDocumentIdentity);
 const plans=arm==='sky'?[{name:'south-road',from:'driftwood-isle',to:null,start:{x:0,z:-230},movement:'road-hover',waypoints:[{x:0,z:-277.5}],requiredResidents:[],retiredResidents:['driftwood-isle']},{name:'sky-entry',from:null,to:'far-reach',movement:'road-hover',waypoints:[{x:0,z:-325}],requiredResidents:['far-reach']}]:[{name:'road',from:'driftwood-isle',to:null,start:{x:0,z:230},movement:'road-hover',waypoints:[{x:0,z:277.5}],requiredResidents:[],retiredResidents:['driftwood-isle']},{name:'pine-entry',from:null,to:'pine-hollow',movement:'road-hover',waypoints:[{x:0,z:325}],requiredResidents:['pine-hollow']},{name:'pine-return',from:'pine-hollow',to:null,movement:'road-hover',waypoints:[{x:0,z:277.5}],requiredResidents:[],retiredResidents:['pine-hollow']},{name:'nalati-road',from:null,to:null,movement:'road-hover',waypoints:[{x:277.5,z:277.5},{x:277.5,z:0}],requiredResidents:[]},{name:'nalati-entry',from:null,to:'nalati-grasslands',movement:'road-hover',waypoints:[{x:325,z:0}],requiredResidents:['nalati-grasslands']}];
 for(const plan of plans){report.stage=plan.name;save();await page.evaluate(`(${stageFloorGrid.toString()})(${JSON.stringify(plan)},${JSON.stringify(identity)})`);const result=await page.evaluate(`(${driveFloorGrid.toString().replaceAll('world.game.watchFrames','window.__g258WatchFrames')})(${JSON.stringify(plan)},${JSON.stringify(identity)})`);report.routes.push(result);const failures=gridFloorWitnessFailures(result);if(failures.length)throw new Error(failures.join('; '));if(plan.to!==null){
  await page.waitForFunction(slug=>{
   const w=window.__wildshard,s=w.shard.grid.state(),f=s.frame;
   if(s.live?.live?.current!==slug||!s.live.live.gameplayReady||f?.owner!==slug)return false;
   if(slug==='nalati-grasslands'){
    const dome=w.world.game.rootScene.getObjectByName('sky-dome-v2');
    if(!dome?.material?.uniforms?.tPano?.value)return false;
    for(let n=dome;n;n=n.parent)if(!n.visible)return false;
    return true;
   }
   return f.skies?.[slug]?.drawn===true&&f.skies[slug].weight>0.99;
  },plan.to,{timeout:45000});
  await page.waitForTimeout(1500);
 }
 const row=await page.evaluate(()=>({witness:window.__wildshard.shard.grid.state(),residency:window.__wildshard.shard.grid.residency(),textures:window.__wildshard.textures(),nalatiDome:(()=>{const d=window.__wildshard.world.game.rootScene.getObjectByName('sky-dome-v2');return d?{name:d.name,visible:d.visible,painted:d.material?.uniforms?.tPano?.value!==undefined}:null;})(),astcExtension:window.__wildshard.world.game.renderer.getContext().getExtension('WEBGL_compressed_texture_astc')!==null,gl:window.__sc_gl().map(({gl,...x})=>x)}));report.snapshots.push({label:plan.name,...row});save();console.log(plan.name,row.residency.cost.playing/1e6,row.textures.mode);if(row.residency.cost.playing>1e9)throw new Error('Strict entered cost exceeds 1GB');if(plan.to!==null&&!row.astcExtension)throw new Error('Probe-accepting GPU lacks ASTC extension');if(plan.to!==null&&row.textures.mode!=='ktx2')throw new Error('Entered compressed arm not selected');}
 report.publicWitness=await page.evaluate(readPublicGridWitness);const failures=publicGridWitnessFailures(report.publicWitness,false);if(failures.length||report.errors.length)throw new Error([...failures,...report.errors].join('; '));report.complete=true;
}catch(e){report.failure=String(e);report.diagnostic=await page?.evaluate(()=>({state:window.__wildshard?.shard?.grid?.state(),residency:window.__wildshard?.shard?.grid?.residency(),text:document.body.innerText.slice(-3000)})).catch(()=>null);process.exitCode=1;}
finally{await context?.close();await pool.close();report.closed=true;save();}
