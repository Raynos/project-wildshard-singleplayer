import { readFileSync, writeFileSync } from 'node:fs';
import { spawn, execFileSync } from 'node:child_process';
import { setTimeout as sleep } from 'node:timers/promises';
import { browserPool } from '/Users/raynos/projects/games/wildshard-singleplayer/scripts/parity/pool.mjs';
import { saveFixture } from '/Users/raynos/projects/games/wildshard-singleplayer/scripts/debug-settings.mjs';
import { GL_INIT } from '/Users/raynos/projects/games/wildshard-singleplayer/scripts/parity/glbytes.mjs';
import { publicGridIntentCode } from '/Users/raynos/projects/games/wildshard-singleplayer/scripts/public-grid.mjs';
import { stageFloorGrid, driveFloorGrid, gridFloorDocumentIdentity, gridFloorWitnessFailures } from '/Users/raynos/projects/games/wildshard-singleplayer/scripts/frame-floor-grid.mjs';
const root='/Users/raynos/projects/games/wildshard-singleplayer',scratch='/private/tmp/claude-501/sp-builders/sp-x5/g258-accounting',base=process.argv[2],out=process.argv[3];
const report={base,diagnosticOnly:true,developer:false,memorySaver:'off',textureSetting:'auto',device:'iPhone 16 Pro',ruler:'Mac Chromium renderer proc_pid_rusage physical footprint + same-pose labelled GL; NOT an iPhone or Simulator reading',snapshots:[],routes:[],errors:[]};
const pool=browserPool(root,1,'metal');let context,page,sampler,phase=out+'.phase',cdp,gamePID,startIdentity;
const save=()=>writeFileSync(out,JSON.stringify(report,null,2)+'\n');
const footprint=pid=>JSON.parse(execFileSync('python3',[scratch+'/footprint.py',String(pid)],{encoding:'utf8'}));
try {
 const browser=await pool.browser(0);cdp=await browser.newBrowserCDPSession();
 context=await browser.newContext({viewport:{width:402,height:874},deviceScaleFactor:3,isMobile:true,hasTouch:true,serviceWorkers:'allow'});
 for(const f of [{scope:'device',key:'devMode',data:false},{scope:'global',key:'settings',data:{tier:'phone',volume:0,fps:'auto',tex:'auto',memorySaver:'off'},merge:true},{scope:'global',key:'gfx',data:{dpr:'2',aa:'auto'}}])await saveFixture(context,f);
 await context.addInitScript(GL_INIT+';'+publicGridIntentCode({instance:'driftwood-isle',slug:'driftwood-isle'})+';window.__wildshardHarness={seed:357,capture:null};');
 page=await context.newPage();page.on('pageerror',e=>report.errors.push(String(e)));await page.route('**/api/**',r=>r.fulfill({status:200,body:'{}'}));
 report.stage='boot';save();await page.goto(base);report.version=await page.evaluate(()=>fetch('/version.json').then(r=>r.json()));
 await page.locator('.ws-main-select').click();await page.locator('.ws-menu-play').click();await page.waitForFunction(()=>window.__wildshard?.shard?.grid?.state().live?.live?.gameplayReady&&window.__wildshard.world.game.app.state==='play',{}, {timeout:240000});
 await page.evaluate(()=>{window.__wildshard.world.hud.enterNow();window.__g258FrameCallback=null;window.__wildshard.world.game.watchFrames(dt=>window.__g258FrameCallback?.(dt));window.__g258WatchFrames=fn=>{window.__g258FrameCallback=fn;return()=>{if(window.__g258FrameCallback===fn)window.__g258FrameCallback=null;};};});
 const identity=await page.evaluate(gridFloorDocumentIdentity);
 const processInfo=await cdp.send('SystemInfo.getProcessInfo');report.processInfo=processInfo;
 const renderers=processInfo.processInfo.filter(p=>p.type==='renderer').map(p=>footprint(p.id)).sort((a,b)=>b.physicalFootprintBytes-a.physicalFootprintBytes);if(!renderers.length)throw new Error('No renderer PID');
 gamePID=renderers[0].pid;startIdentity=renderers[0].startAbstime;report.gamePID=gamePID;report.startAbstime=startIdentity;
 writeFileSync(phase,'home');sampler=spawn('python3',[scratch+'/footprint.py',String(gamePID),phase,out+'.native.jsonl'],{stdio:'ignore'});
 const snapshot=async label=>{
  report.stage=label;writeFileSync(phase,label);save();await sleep(5000);const samples=[];
  for(let i=0;i<3;i++){await sleep(1100);const row=footprint(gamePID);if(row.startAbstime!==startIdentity)throw new Error('Renderer PID changed');samples.push(row);}
  const ledger=await page.evaluate(()=>({gl:window.__sc_gl().map(({gl,...r})=>r),state:window.__wildshard.shard.grid.state(),residency:window.__wildshard.shard.grid.residency(),textures:window.__wildshard.textures(),developer:Object.hasOwn(document.documentElement.dataset,'dev'),settings:JSON.parse(localStorage.getItem('wildshard.save.v2.global')).keys.settings.data}));
  const gpu=ledger.gl.reduce((a,g)=>a+g.totalBytes,0);if(!ledger.gl.every(g=>g.reconciled&&g.resources.reduce((n,r)=>n+(r.labelled?0:r.bytes),0)===0))throw new Error('Unreconciled identity GL ledger');
  const median=samples.map(s=>s.physicalFootprintBytes).sort((a,b)=>a-b)[1];report.snapshots.push({label,samples,physicalFootprintBytes:median,labelledGLBytes:gpu,combinedBytes:median+gpu,ledger});save();console.log(label,median/1e6,gpu/1e6,ledger.textures.mode);
 };
 const run=async plan=>{report.stage='route:'+plan.name;writeFileSync(phase,report.stage);save();await page.evaluate(`(${stageFloorGrid.toString()})(${JSON.stringify(plan)},${JSON.stringify(identity)})`);const result=await page.evaluate(`(${driveFloorGrid.toString().replaceAll('world.game.watchFrames','window.__g258WatchFrames').replace('hover: player.hover });', 'hover: player.hover, ground: player.groundHeightAt(player.position.x, player.position.z) });')})(${JSON.stringify(plan)},${JSON.stringify(identity)})`);report.routes.push(result);save();const failures=gridFloorWitnessFailures(result);result.originalWitnessFailures=failures; const groundWitness = result.trace.length > 0 && result.trace.every(row=>Number.isFinite(row.ground)&&Number.isFinite(row.y)&&row.y>=row.ground-0.25); result.authoredGroundWitness=groundWitness; const fails=failures.filter(f=>f!=='Route has no valid above-ground motion witness'||!groundWitness); save();if(fails.length)throw new Error(fails.join('; '));await snapshot(plan.name);};
 await snapshot('home');
 for(const plan of [{name:'road',from:'driftwood-isle',to:null,start:{x:0,z:230},movement:'road-hover',waypoints:[{x:0,z:277.5}],requiredResidents:[],retiredResidents:['driftwood-isle']},{name:'pine-entry',from:null,to:'pine-hollow',movement:'road-hover',waypoints:[{x:0,z:325}],requiredResidents:['pine-hollow']},{name:'pine-centre',from:'pine-hollow',to:'pine-hollow',movement:'road-hover',waypoints:[{x:.92,z:554.08}],requiredResidents:['pine-hollow']},{name:'road-return',from:'pine-hollow',to:null,movement:'road-hover',waypoints:[{x:0,z:325},{x:0,z:277.5}],requiredResidents:[],retiredResidents:['pine-hollow']}])await run(plan);
 const pine=report.snapshots.find(s=>s.label==='pine-entry');if(pine.ledger.textures.mode!=='ktx2'||pine.ledger.textures.probe?.veto!==null)throw new Error('This GPU did not accept compressed textures');
 report.complete=true;
}catch(error){report.failure=String(error);report.diagnostic=await page?.evaluate(()=>({text:document.body.innerText.slice(-3500),state:window.__wildshard?.shard?.grid?.state(),stop:window.__frameFloorGridStop})).catch(()=>null);process.exitCode=1;}
finally{writeFileSync(phase,'done');if(sampler){await Promise.race([new Promise(r=>sampler.once('exit',r)),sleep(1500)]);if(sampler.exitCode===null)sampler.kill('SIGTERM');}await context?.close();await pool.close();report.closed=true;save();}
