import importlib.util,json,sys,time,os
s=importlib.util.spec_from_file_location('watchdog','/Users/raynos/projects/games/wildshard-singleplayer/scripts/ios-memory-watchdog.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);n=m.NativeMemory()
if len(sys.argv)==2:print(json.dumps(n.sample(int(sys.argv[1]))));sys.exit(0)
pid=int(sys.argv[1]);phase=sys.argv[2];out=open(sys.argv[3],'x');start=time.monotonic();last=None
while True:
 p=open(phase).read().strip()
 if p=='done':break
 if p!=last:n.reset_interval(pid);last=p
 row=n.sample(pid);row.update(phase=p,elapsed=time.monotonic()-start,load1=os.getloadavg()[0]);out.write(json.dumps(row)+'\n');out.flush();time.sleep(.1)
