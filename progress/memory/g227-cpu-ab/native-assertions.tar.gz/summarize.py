import json,statistics,hashlib,gzip
from pathlib import Path
out=Path(__file__).parent
pins=json.loads((out/'pins.json').read_text());rows=[]
attempts=json.loads((out/'native-attempts.json').read_text())
for attempt in attempts['attempts']:
 if not attempt['valid']:continue
 path=out/attempt['file'];r=json.loads(path.read_text());label=attempt['side']
 assert r.get('closed') and not r.get('failure'),(path,r.get('failure'))
 assert json.loads(r.get('errors') or '[]')==[],(path,r.get('errors'))
 for s in r['snapshots']:
  native=s['native'];gl=sum(c['totalBytes'] for c in s['census']['gl'])
  rows.append({'run':path.name,'side':label,'pose':s['label'],'pid':r['gamePID'],'nativeSamples':native['samples'],'nativeMedian':native['medianBytes'],'nativeMin':native['minBytes'],'nativeMax':native['maxBytes'],'labelledGLBytes':gl,'combinedBytes':native['medianBytes']+gl,'modelPlayingBytes':s['residency']['cost']['playing'],'sceneArrayBytes':sum(a['bytes'] for a in s['census']['cpuAllocations'])})
assert len(set(r['run'] for r in rows))==6
assert len(set(r['pid'] for r in rows))==6
metrics={}
for pose in sorted(set(r['pose'] for r in rows)):
 metrics[pose]={}
 for side in ['baseline','candidate']:
  cases=[r for r in rows if r['pose']==pose and r['side']==side];assert len(cases)==3
  stats={}
  for metric in ['nativeMedian','labelledGLBytes','combinedBytes','sceneArrayBytes']:
   values=[r[metric] for r in cases];stats[metric]={'values':values,'median':statistics.median(values),'min':min(values),'max':max(values),'spread':max(values)-min(values)}
  metrics[pose][side]=stats
 metrics[pose]['baselineMinusCandidate']={m:metrics[pose]['baseline'][m]['median']-metrics[pose]['candidate'][m]['median'] for m in metrics[pose]['baseline']}
report={'pins':pins,'attempts':attempts,'failureCounts':{side:sum(1 for a in attempts['attempts'] if a['side']==side and not a['valid']) for side in ['baseline','candidate']},'protocol':'Six separate cold Simulator boots, three per side, Memory saver ON, identical non-CPU source/settings. Three independent fresh per-PID one-second kernel samples at each real entered pose. Labelled GL summed separately. macOS Simulator relative evidence, not physical-phone cap proof. Released pixel payload is not an assumed native saving. Full spreads printed; no budget discount.','runs':rows,'metrics':metrics}
report['failureCategories']={side:{'premeasurementInspector':sum(a['side']==side and not a['valid'] and a['pid'] is None for a in attempts['attempts']),'postfenceGraphicsRecovery':sum(a['side']==side and not a['valid'] and a['pid'] is not None for a in attempts['attempts']),'measuredAttempts':sum(a['side']==side and a['pid'] is not None for a in attempts['attempts'])} for side in ['baseline','candidate']}
report['verdict']={'validColdRunsPerSide':3,'nativeMemoryCreditBytes':0,'reason':'Observed centre median difference is smaller than cold-run spread; candidate has two post-fence graphics recovery failures versus zero baseline GPU failures. Do not infer causal savings or stability.','capPass':False,'phoneCapProof':False,'qualifyingSf57':False}
report['commands']=['scripts/browser-lane.sh -- scripts/sim-lane.sh --device=sp-x1-g227-cpu -- node progress/memory/g227-budget/native.mjs <preview-url> <attempt.json> pine-centre','node --test scripts/soak/owned.test.mjs (14/14)','pnpm exec vitest run test/parity-speed.test.ts (9/9)']
(out/'native-summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(metrics,indent=2))
