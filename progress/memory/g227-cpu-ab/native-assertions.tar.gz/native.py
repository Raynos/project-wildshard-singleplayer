import subprocess,os,json,sys
from pathlib import Path
root=Path('/Users/raynos/projects/games/wildshard-singleplayer');out=Path(__file__).parent
previews=json.loads((out/'previews.json').read_text());env=os.environ.copy();env['CLAUDE_CODE_SESSION_ID']='sp-x1-g227-cpu-ab'
env.pop('G227_NATIVE_DETAIL',None)
manifest=out/'native-attempts.json'
previous=json.loads(manifest.read_text()) if manifest.exists() else {'valid':{'baseline':0,'candidate':0},'attempts':[]}
valid=previous['valid'];attempts=previous['attempts'];pids=[r['pid'] for r in attempts if r['valid']]
schedule=['baseline','candidate','candidate','baseline','baseline','candidate']
while min(valid.values())<3:
 index=len(attempts)+1
 if index>18:raise RuntimeError('18 preserved attempts without three valid per side; report incomplete instead of sampling indefinitely')
 label=schedule.pop(0) if schedule else min(valid,key=lambda side:(valid[side],side))
 if valid[label]>=3:continue
 preview=previews[label];dist=Path(preview['dist']);dist=dist if (dist/'index.html').exists() else dist/'dist'
 report=out/f'native-{index:02d}-{label}.json'
 command=[str(root/'scripts/browser-lane.sh'),'--max','12',str(root/'scripts/sim-lane.sh'),'run','--max','12','sp-x1-g227-cpu','node','progress/memory/g227-budget/native.mjs',preview['url'],str(report),str(dist),'pine-centre','on']
 print('NATIVE START',index,label,flush=True);result=subprocess.run(command,cwd=root,env=env,check=False)
 record=json.loads(report.read_text());errors=json.loads(record.get('errors') or '[]')
 success=result.returncode==0 and record.get('closed') and not record.get('failure') and errors==[]
 if success:
  pid=record['gamePID'];assert pid not in pids,('Not a fresh WebContent PID',pid);pids.append(pid)
  assert len(record['routes'])==2 and len(record['snapshots'])==3
  assert all(s['settings']['memorySaver']=='on' and len(s['native']['samples'])==3 for s in record['snapshots'])
  valid[label]+=1
 attempts.append({'attempt':index,'side':label,'file':report.name,'returncode':result.returncode,'valid':bool(success),'failure':record.get('failure'),'stage':record.get('stage'),'pid':record.get('gamePID')})
 (out/'native-attempts.json').write_text(json.dumps({'valid':valid,'attempts':attempts},indent=2)+'\n')
 print('NATIVE COMPLETE' if success else 'NATIVE FAILED',index,label,valid,flush=True)
 if not success:
  text=json.dumps(record).lower()
  bootInspector=record.get('gamePID') is None and not record.get('snapshots') and "'runtime' domain was not found" in text
  if not record.get('closed') or not (bootInspector or 'document changed' in text or 'graphics recovery' in text or 'gpu process restarted' in text):raise RuntimeError('Unexpected failure; preserved, must diagnose before retry')
print('SIX VALID COLD RUNS COMPLETE',pids,flush=True)
