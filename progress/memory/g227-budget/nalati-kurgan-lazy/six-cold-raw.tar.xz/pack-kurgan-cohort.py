from pathlib import Path
import hashlib, io, json, statistics, tarfile

root = Path('/private/tmp/claude-501/sp-builders/sp-x4')
dest = Path('/Users/raynos/projects/games/wildshard-singleplayer/progress/memory/g227-budget/nalati-kurgan-lazy')
attempts = json.loads((root / 'kurgan-native-attempts.json').read_text())
manifest = json.loads((root / 'kurgan-native-manifest.json').read_text())
assert all(a['status'] in ['valid', 'failed'] for a in attempts)
valid = {side: [a for a in attempts if a['side'] == side and a['status'] == 'valid'] for side in ['before', 'after']}
assert all(len(runs) == 3 for runs in valid.values())

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def stats(values):
    return {'runs': values, 'median': statistics.median(values), 'min': min(values), 'max': max(values), 'spread': max(values)-min(values)}

labels = ['home-settled', 'nalati-grasslands-entry', 'nalati-grasslands-centre', 'neutral-road']
summary = {}
for label in labels:
    sides = {}
    for side, runs in valid.items():
        poses = [next(p for p in a['poses'] if p['label'] == label) for a in runs]
        sides[side] = {key: stats([p[key] for p in poses]) for key in ['webContentBytes', 'glBytes', 'sumBytes']}
    sides['afterMinusBeforeMedian'] = {key: sides['after'][key]['median']-sides['before'][key]['median'] for key in ['webContentBytes', 'glBytes', 'sumBytes']}
    summary[label] = sides

witnesses = []
for a in attempts:
    p = Path(a['out'])
    if not p.exists():
        continue
    d = json.loads(p.read_text())
    centre = next(s for s in d['snapshots'] if s['label'] == 'nalati-grasslands-centre')
    arrays = centre['census']['cpuAllocations']
    kurgan = [x for x in arrays if any('kurgan-interior' in use['user'] for use in x['uses'])]
    expected = 12022128 if a['side'] == 'before' else 0
    assert sum(x['bytes'] for x in kurgan) == expected
    assert all(s['settings']['memorySaver'] == 'on' for s in d['snapshots'])
    assert not d.get('failure') and d['closed'] and json.loads(d['errors']) == []
    assert d['sampler']['exitCode'] == 0 and not d['sampler']['signal'] and not d['sampler']['error']
    witnesses.append({'side': a['side'], 'number': a['number'], 'version': d['version'], 'gamePID': d['gamePID'],
        'settings': centre['settings'], 'devicePicks': centre['devicePicks'], 'audioContexts': centre['audioContexts'],
        'centreCpuBackingBytes': sum(x['bytes'] for x in arrays), 'kurganBackingBytes': expected,
        'samples': {s['label']: s['native']['samples'] for s in d['snapshots']},
        'closed': d['closed'], 'errors': json.loads(d['errors']), 'sampler': d['sampler']})

files = {root / 'kurgan-native-attempts.json', root / 'kurgan-native-manifest.json',
         root / 'run-kurgan-native-attempt.py', root / 'pack-kurgan-cohort.py', root / 'kurgan-cohort-driver.log'}
for a in attempts:
    stem = f"kurgan-native-{a['side']}-attempt-{a['number']}"
    files.update(root.glob(stem + '.*'))
files.update(Path(manifest['driver'], p) for p in manifest['helperFiles'])
raw = []
archive = dest / 'six-cold-raw.tar.xz'
with tarfile.open(archive, mode='w:xz') as tar:
    for p in sorted(files):
        assert p.is_file()
        name = str(p.relative_to(root))
        data = p.read_bytes()
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        tar.addfile(info, io.BytesIO(data))
        raw.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})

receipt = {
    'protocol': manifest['protocol'],
    'before': manifest['sourceBefore'], 'after': manifest['sourceAfter'], 'helperSha': manifest['helperSha'],
    'attemptCounts': {side: {status: sum(a['side'] == side and a['status'] == status for a in attempts) for status in ['valid', 'failed']} for side in valid},
    'summary': summary, 'attempts': attempts, 'witnesses': witnesses,
    'sourceWitness': {'centreCpuBytesAvoided': 12022128, 'centreGlChangeBytes': 0},
    'nativeCreditBytes': 0,
    'limitation': 'Three valid cold runs per arm, not a physical-phone cap reading. Native medians/ranges are reported; overlapping variation is not credited as a saving. One baseline launch failed before game load because the scratch helper lacked the checkout-inherited ws package; its log is retained and the same dependency was linked explicitly without changing helper source.',
    'rawArchive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': digest(archive), 'files': raw},
}
(dest / 'six-cold.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'counts': receipt['attemptCounts'], 'centre': summary['nalati-grasslands-centre'], 'archiveBytes': archive.stat().st_size}, indent=2))
