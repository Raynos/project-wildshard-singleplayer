from pathlib import Path
from datetime import datetime,timezone
import os,json,subprocess,sys,statistics,hashlib
r=Path('/private/tmp/claude-501/sp-builders/sp-x4');repo=Path('/Users/raynos/projects/games/wildshard-singleplayer');side=sys.argv[1]
assert side in ['before','after'];manifest=json.loads((r/'kurgan-native-manifest.json').read_text());preview=manifest['previews'][side];ledger=r/'kurgan-native-attempts.json';attempts=json.loads(ledger.read_text()) if ledger.exists() else []
number=1+max([a['number'] for a in attempts if a['side']==side],default=0);out=r/f'kurgan-native-{side}-attempt-{number}.json';log=out.with_suffix('.log');assert not out.exists() and not log.exists()
for p,h in manifest['helperFiles'].items():assert hashlib.sha256(Path(manifest['driver'],p).read_bytes()).hexdigest()==h,p
version=json.loads(subprocess.check_output(['curl','--fail','--silent',preview['base']+'version.json'],text=True));assert version==preview['version']
a={'side':side,'number':number,'startedUtc':datetime.now(timezone.utc).isoformat(),'helperSha':manifest['helperSha'],'out':str(out),'log':str(log),'version':version,'status':'running'};attempts.append(a);ledger.write_text(json.dumps(attempts,indent=2)+'\n')
command=[str(repo/'scripts/browser-lane.sh'),'--max','15',str(repo/'scripts/sim-lane.sh'),'run','--max','15','wildshard-iphone','node','progress/memory/g227-budget/native.mjs',preview['base'],str(out),preview['dist'],'nalati-route','on'];a['command']=command;ledger.write_text(json.dumps(attempts,indent=2)+'\n');env={**os.environ,'G227_NATIVE_DETAIL':'1'}
with log.open('w') as f:
 result=subprocess.run(command,cwd=manifest['driver'],env=env,stdout=f,stderr=subprocess.STDOUT)
a['exitCode']=result.returncode;a['finishedUtc']=datetime.now(timezone.utc).isoformat();failures=[]
if result.returncode:failures.append('owned command exit '+str(result.returncode))
if out.exists():
 d=json.loads(out.read_text());a['rawSha256']=hashlib.sha256(out.read_bytes()).hexdigest()
 if not d.get('closed'):failures.append('resources not confirmed closed')
 if d.get('failure'):failures.append(d['failure'])
 try:errors=json.loads(d.get('errors') or 'null')
 except (ValueError,TypeError):errors=None
 if errors!=[]:failures.append('errors not empty: '+str(errors))
 sampler=d.get('sampler',{})
 if sampler.get('exitCode')!=0 or sampler.get('error') or sampler.get('signal'):failures.append('sampler failed: '+str(sampler))
 labels=['home-settled','nalati-grasslands-entry','nalati-grasslands-centre','neutral-road'];snaps=d.get('snapshots',[])
 if [s['label'] for s in snaps]!=labels:failures.append('incomplete settled pose sequence')
 last='';poses=[]
 for s in snaps:
  samples=s.get('native',{}).get('samples',[])
  if len(samples)!=3:failures.append('missing three samples at '+s['label']);continue
  for sample in samples:
   if sample['pid']!=d.get('gamePID') or sample['at']<=last:failures.append('PID/timestamp fence at '+s['label'])
   last=sample['at']
  if s.get('settings',{}).get('memorySaver')!='on':failures.append('Memory saver not ON at '+s['label'])
  wc=statistics.median(p['footprintBytes'] for p in samples)
  if wc!=s['native']['medianBytes']:failures.append('median mismatch at '+s['label'])
  gl=sum(g['totalBytes'] for g in s['census']['gl']);poses.append({'label':s['label'],'webContentBytes':wc,'glBytes':gl,'sumBytes':wc+gl,'sampleTimestamps':[p['at'] for p in samples]})
 a['poses']=poses;a['gamePID']=d.get('gamePID');a['failureStage']=d.get('stage');a['sampler']=sampler
else:failures.append('no report produced')
a['status']='failed' if failures else 'valid';a['failures']=failures;ledger.write_text(json.dumps(attempts,indent=2)+'\n')
print(json.dumps(a,indent=2));print('counts',json.dumps({s:{k:sum(x['side']==s and x['status']==k for x in attempts) for k in ['valid','failed']} for s in ['before','after']}));sys.exit(1 if failures else 0)
