// G227 one cold Simulator grid route, kernel footprint and labelled GL at entered poses.
// --census=final (default) | none | every. The in-page census (snapshotExpression) walks the scene and every texture and
// buffer; WebKit keeps the 50-300 MB of WebContent it allocates, so a census inflates every LATER reading in the same page
// (grid-base, c2d910073). final: every pose reads the kernel footprint and a light GL total (the tracker's per-context
// sums, no scene walk), and one full census runs after the last pose's reading. none: no census. every: the legacy order
// (a census after each pose's reading), kept only to compare against old receipts.
// Route mode standalone-pine boots ?chunk=pine-hollow and reads its spawn and centre (the grid-base pose) with the same
// sampler, for a like-for-like grid-vs-standalone comparison.
import { spawn, execFileSync } from 'node:child_process';
import WebSocket from '/Users/raynos/node_modules/ws/index.js';
import { memoryCategories } from '/Users/raynos/projects/games/wildshard-singleplayer/progress/memory/g227-budget/memory-categories.mjs';
import { waitNativeSample } from '/Users/raynos/projects/games/wildshard-singleplayer/progress/memory/g227-budget/native-samples.mjs';
import { AUDIO_INIT, WASM_INIT, snapshotExpression, heapOwners } from '/Users/raynos/projects/games/wildshard-singleplayer/progress/memory/g227-budget/inspect.mjs';
import { closeSync, openSync, readFileSync, writeFileSync } from 'node:fs';
import { setTimeout as sleep } from 'node:timers/promises';
import { GL_INIT } from '/Users/raynos/projects/games/wildshard-singleplayer/scripts/parity/glbytes.mjs';
import { installResources } from '/Users/raynos/projects/games/wildshard-singleplayer/scripts/parity/resources.mjs';
import { soakBootPoll } from '/Users/raynos/projects/games/wildshard-singleplayer/scripts/soak/owned.mjs';
import { saveFixtureCode } from '/Users/raynos/projects/games/wildshard-singleplayer/scripts/debug-settings.mjs';
import { gridFloorDocumentIdentity, gridFloorPlans, runFloorGridRoute, gridFloorWitnessFailures } from '/Users/raynos/projects/games/wildshard-singleplayer/scripts/frame-floor-grid.mjs';
import { publicGridIntentCode, publicGridPlans, readPublicGridWitness, publicGridWitnessFailures } from '/Users/raynos/projects/games/wildshard-singleplayer/scripts/public-grid.mjs';

const argv = process.argv.slice(2);
const censusMode = argv.find(arg => arg.startsWith('--census='))?.slice('--census='.length) ?? 'final';
if (!['final', 'none', 'every'].includes(censusMode)) throw new Error('--census must be final, none or every');
// --gl=every (default): the light GL read follows each pose's footprint samples. --gl=last: no in-page read at all before a
// pose's samples, GL read once after the last pose (footprint-only control; such runs carry GL on the last pose only).
const glMode = argv.find(arg => arg.startsWith('--gl='))?.slice('--gl='.length) ?? 'every';
if (!['every', 'last'].includes(glMode)) throw new Error('--gl must be every or last');
// --vmmap=last (default) | every. vmmap -summary on the WebContent task inflates its later footprint readings by
// hundreds of MB (ruler lane, Pine centre: 478 MB without, 903 MB with a vmmap at each earlier pose), so it runs once,
// after the last pose's reading. every is the old order, for comparison with old receipts only.
const vmmapMode = argv.find(arg => arg.startsWith('--vmmap='))?.slice('--vmmap='.length) ?? 'last';
if (!['every', 'last'].includes(vmmapMode)) throw new Error('--vmmap must be every or last');
const [base, out, dist, routeMode = 'full', memorySaver = 'off', entryEdge = 'north'] = argv.filter(arg => !arg.startsWith('--')), udid = process.env.SIM_UDID;
const standalone = routeMode === 'standalone-pine';
if (standalone && censusMode !== 'none') throw new Error('standalone-pine has no grid for the census: pass --census=none');
const publicGrid = false;
if (routeMode === 'sun-entry' && !['north', 'east', 'south', 'west'].includes(entryEdge)) throw new Error('Unknown Sun entry edge');
if (publicGrid && memorySaver !== 'off') throw new Error('Public grid measures the shipping Memory saver default OFF');
if (!['off', 'on'].includes(memorySaver)) throw new Error('Memory saver must be off or on');
// GPU textures (Settings ▸ Debug): the build default Auto unless a run pins KTX2 / Images (sky-mem's ASTC A/B)
const tex = 'img';
if (!['auto', 'ktx2', 'img'].includes(tex)) throw new Error('G227_TEX must be auto, ktx2 or img');
if (!dist) throw new Error('Pass the owned preview dist directory for the preboot diagnostic helper');
const fixtures = [
  {scope:'global',key:'settings',data:{tier:'phone',fps:'auto',tex,memorySaver,volume:0},merge:true},
  {scope:'global',key:'gfx',data:{dpr:'2',aa:'auto'}},
  {scope:'device',key:'devMode',data:!publicGrid},
].map(saveFixtureCode).join(';');
const helper = new URL('g227-safari.html', base).href;
// A preview may serve several cold variants. Remove only this harness's earlier inline fixture before reseeding.
const builtHtml = readFileSync(dist + '/index.html','utf8').replace(/<script(?: data-g227-fixture)?>([\s\S]*?)<\/script>/gu,
  (tag, body) => body.includes('window.__g227Errors=[];') ? '' : tag);
const resourceFixture = ['sky-entry', 'sun-entry'].includes(routeMode) ? `(${installResources.toString()})();` : '';
const resourcePort = ['sky-entry', 'sun-entry'].includes(routeMode) ? ',resources:()=>window.__parityResources()' : '';
const catalogue=JSON.parse(readFileSync('/private/tmp/wildshard-serve/20261014-090218-4403/src/src/game/grid/singleplayer.json','utf8')).grid;
const cells=new Map(catalogue.cells.map(row=>[row.cell.join(','),row]));for(const row of catalogue.developer)cells.set(row.cell.join(','),row);
const catalogueKey=JSON.stringify({pitch:catalogue.pitch,cells:[...cells.values()].map(row=>[row.instance,row.slug,...row.cell]).sort((a,b)=>String(a[0]).localeCompare(String(b[0])))});
const recoveryCode=publicGridIntentCode({instance:'driftwood-isle',slug:'driftwood-isle'}).replace("const target={...", "const target={catalogue:"+JSON.stringify(catalogueKey)+",reason:'reload',road:{x:832.5,z:832.5,yaw:Math.PI},...").replaceAll("key:'gridIntent'","key:'grid.recovery.once'").replaceAll("key:'gridIntent.once'","key:'grid.recovery.once'");
const documentHtml = builtHtml.replace('<head>', '<head><script data-g227-fixture>' + resourceFixture + GL_INIT + ';' + '' + ';' + '' + ';' + fixtures + ';' + recoveryCode + ';window.__wildshardHarness={textures:"img",seed:357,capture:null'+resourcePort+'};window.__gridAdmissionLongTasks=[];window.__g227Errors=[];window.__g227Warnings=[];{const warn=console.warn;console.warn=(...args)=>{if(window.__g227Warnings.length<100)window.__g227Warnings.push(args.map(x=>x?.stack??String(x)).join(" "));warn.apply(console,args);};}window.addEventListener("error",e=>window.__g227Errors.push(String(e.message)));window.addEventListener("unhandledrejection",e=>window.__g227Errors.push(String(e.reason)));<\/script>');
writeFileSync(dist + '/index.html', documentHtml);
writeFileSync(dist + '/g227-safari.html', documentHtml);
if (!udid) throw new Error('Run through sim-lane.sh');
const report = { version: await (await fetch(new URL('version.json', base))).json(), routeMode, memorySaver, tex, developer:!publicGrid, census: censusMode, glRead: glMode, vmmap: vmmapMode,
  ...(publicGrid ? {publicGrid:'public grid as it would ship once GRID_GATES_PASSED flips'} : {}),
  diagnosticOnly:true, permission:'wildshard-new: G258 DW matched cold-road increment, production admission unchanged; images resolved naturally', protocol: 'One cold Safari Simulator route. Three settled one-second kernel physical-footprint samples per pose; live labelled GL (tracker totals) at the same pose; the in-page census only as --census says (final: once, after the last reading). Relative evidence, not physical-phone cap proof.',
  snapshots: [], routes: [] };
const save = () => writeFileSync(out, JSON.stringify(report, null, 2) + '\n');
// The light GL read: the tracker's per-context sums. No scene walk, no labelling, no per-resource rows returned.
const lightExpression = `(() => ({
  gl: window.__sc_gl().map(({ gl, resources, top, ...context }) => ({ ...context, unlabelledBytes: resources.reduce((sum, row) => sum + (row.labelled ? 0 : row.bytes), 0) })),
  settings: JSON.parse(localStorage.getItem('wildshard.save.v2.global') ?? '{}').keys?.settings?.data,
}))()`;
const phaseFile = out + '.phase', nativeFile = out + '.native.jsonl';
writeFileSync(phaseFile, 'loading');
const simctl = args => execFileSync('xcrun', ['simctl', ...args], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
let inspector, sampler, proxy, gamePID, beforeMeasurement = true;
const samplerState = { pid: null, exitCode: null, signal: null, error: null, log: out + '.sampler.log' };
report.sampler = samplerState;
const nativeDetail = process.env.G227_NATIVE_DETAIL === '1';
let evalSequence = 0;
try {
  try { simctl(['terminate', udid, 'com.apple.mobilesafari']); } catch { /* Cold first launch. */ }
  report.stage = 'cold-version'; save();
  simctl(['openurl', udid, `${base}version.json`]);
  await sleep(6000);
  const socket = simctl(['getenv', udid, 'RWI_LISTEN_SOCKET']).trim();
  proxy = spawn('ios_webkit_debug_proxy', ['-s', `unix:${socket}`, '-c', 'null:9221,:9232-9240', '-F'], { stdio: 'ignore' });
  const connect = async url => {
    inspector?.close(); inspector = webkit(await safariPage(url)); await inspector.opened; await sleep(600);
    return evaluator(inspector.raw);
  };
  let evaluate = await connect(`${base}version.json`);
  report.stage = 'cold-reset'; save();
  await evaluate(`(async () => {for(const r of await navigator.serviceWorker.getRegistrations()) await r.unregister();for(const k of await caches.keys()) await caches.delete(k);localStorage.clear();sessionStorage.clear();return true;})()`);
  await evaluate(`(() => {${saveFixtureCode({ scope: 'global', key: 'settings', data: { tier: 'phone', fps: 'auto', tex, memorySaver }, merge: true })};${saveFixtureCode({ scope: 'global', key: 'gfx', data: { dpr: '2', aa: 'auto' } })};${saveFixtureCode({ scope: 'device', key: 'devMode', data: !publicGrid })};return true;})()`);
  const samplerLog = openSync(samplerState.log, 'wx');
  try { sampler = spawn('python3', ['scripts/sim-mem-phases.py', '--device', udid, '--phase-file', phaseFile, '--out', nativeFile, '--max', '1200'], { stdio: ['ignore', samplerLog, samplerLog] }); }
  finally { closeSync(samplerLog); }
  samplerState.pid = sampler.pid ?? null;
  sampler.on('error', error => { samplerState.error = String(error); });
  sampler.on('exit', (code, signal) => { samplerState.exitCode = code; samplerState.signal = signal; });
  if (routeMode === 'control') {
    await evaluate(`(() => { ${GL_INIT}; return true; })()`);
    await evaluate(`(() => { const gl=document.createElement('canvas').getContext('webgl2'); const texture=gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D,texture); gl.texStorage2D(gl.TEXTURE_2D,1,gl.RGBA8,1,1); gl.finish(); window.__g227WarmGL={gl,texture}; return true;})()`);
    await sleep(3000);
    report.stage='isolated-gl-control';save();
    report.glFootprintControl=await footprintControl(evaluate);save();
    await evaluate(`(() => { const {gl,texture}=window.__g227WarmGL;gl.deleteTexture(texture);gl.getExtension('WEBGL_lose_context')?.loseContext();delete window.__g227WarmGL;return true;})()`);
  } else {
  report.stage = 'title-load'; save();
  simctl(['openurl',udid,`${helper}?chunk=driftwood-isle&tier=phone&mute=1&nolock=1&sw=0`]);
  await sleep(3000);
  evaluate = await connect(helper);
  const until = async (expression, ms = 180000) => {
    for (const started = Date.now(); Date.now() - started < ms;) {
      // Title navigation may replace WebKit's process target before the measurement document exists.
      // Reuse the shared exact-error handshake; once fenced, every protocol/game error is fatal.
      const status = await soakBootPoll(() => evaluate(`({ready:Boolean(${expression}),fatal:document.getElementById('wserr')?.innerText ?? null})`), beforeMeasurement);
      if (status !== false) {
        if (status.fatal !== null) throw new Error('Native boot failed: ' + status.fatal);
        if (status.ready) return;
      }
      await sleep(500);
    }
    throw new Error('Readiness timed out: ' + expression);
  };
  if(publicGrid){await until("Boolean(document.querySelector('.ws-main-select'))");await evaluate("(document.querySelector('.ws-main-select').click(),true)");await until("Boolean(document.querySelector('.ws-menu-play'))");await inspector.raw("(setTimeout(()=>document.querySelector('.ws-menu-play').click(),100),true)");await sleep(3000);evaluate=await connect(helper);}
  report.stage = 'grid-load'; save();
  if (standalone) {
    await until("!document.querySelector('.ws-load') && Boolean(window.__wildshard?.world?.player)", 240000);
    // The standalone boot rewrites the global save once after load; wait for the seeded settings to be back on disk.
    await until(`JSON.parse(localStorage.getItem('wildshard.save.v2.global') ?? '{}').keys?.settings?.data?.memorySaver === ${JSON.stringify(memorySaver)}`, 30000);
    await sleep(4000);
  } else {
  await until("!document.querySelector('.ws-load') && Boolean(window.__wildshard?.shard?.grid?.state().live?.live)", 240000);
  await evaluate('(window.__wildshard.world.hud.enterNow(),true)');
  await until("window.__wildshard?.state().appState==='play'");
  }
  const documentOrigin = await evaluate(`(${gridFloorDocumentIdentity.toString()})()`); report.documentOrigin = documentOrigin; beforeMeasurement = false;
  const snapshot = async label => {
    report.stage = label; writeFileSync(phaseFile, label); save(); await sleep(5000);
    const samples = [];
    for (let i = 0; i < 3; i++) {
      await sleep(1100);
      const sample = await waitNativeSample(() => readFileSync(nativeFile, 'utf8'), () => samplerState,
        { phase: label, pid: gamePID, after: samples.at(-1)?.at });
      gamePID ??= sample.pid; report.gamePID = gamePID; samples.push(sample);
    }
    // Nothing in-page that allocates runs before the samples above. vmmap is out of process.
    const sorted = samples.map(s => s.footprintBytes).sort((a, b) => a - b);
    const vmmapPath = out.replace(/\.json$/u, '') + '.' + label + '.vmmap.txt';
    let vmmap = 'deferred';
    if (vmmapMode === 'every') {
      try { vmmap = execFileSync('vmmap', ['-summary', String(samples[2].pid)], { encoding: 'utf8', timeout: 30000, maxBuffer: 8e6 }); writeFileSync(vmmapPath, vmmap); }
      catch (error) { vmmap = String(error); }
    }
    const light = glMode === 'every' ? await evaluate(lightExpression) : null;
    const glBytes = light === null ? null : light.gl.reduce((sum, context) => sum + context.totalBytes, 0);
    const value = censusMode === 'every' ? await evaluate(snapshotExpression) : {};
    if (publicGrid) {
      value.publicWitness = await evaluate(`(${readPublicGridWitness.toString()})()`);
      const failures = publicGridWitnessFailures(value.publicWitness, false);
      if (failures.length > 0) throw new Error(failures.join('; '));
    }
    if (light !== null && (light.settings?.memorySaver ?? 'off') !== memorySaver) throw new Error('Memory saver fixture did not activate: expected ' + memorySaver + ', observed ' + light.settings?.memorySaver);
    const detail = {};
    if (nativeDetail) {
      // Original WC/GL samples above stay intact; passive diagnostics happen afterwards, without collecting the heap.
      detail.memoryCategories = await memoryCategories(inspector);
      for (const [name, command, args] of [
        ['vmmapVerbose', 'vmmap', ['-v', String(gamePID)]],
        ['footprint', 'footprint', ['-f', 'bytes', '-p', String(gamePID)]],
      ]) {
        const path = out.replace(/\.json$/u, '') + '.' + label + '.' + name + '.txt';
        try { writeFileSync(path, execFileSync(command, args, { encoding: 'utf8', timeout: 30000, maxBuffer: 16e6 })); detail[name] = { path, pid: gamePID }; }
        catch (error) { detail[name] = { error: String(error), pid: gamePID }; }
      }
    }
    const accounting = await evaluate('({residency:window.__wildshard.shard.grid.residency(),state:window.__wildshard.shard.grid.state(),textures:window.__wildshard.textures()})');
    report.snapshots.push({ label, glBytes, light, accounting, ...value, native: { samples, medianBytes: sorted[1], minBytes: sorted[0], maxBytes: sorted[2], vmmapPath, vmmapError: vmmap.startsWith('Error:') ? vmmap : null, ...detail } });
    save(); console.log(label, 'native', sorted[1] / 1e6, 'GL', glBytes === null ? 'after last pose' : glBytes / 1e6, 'census', censusMode === 'every' ? 'after this reading' : 'not yet');
  };
  // --census=final: one full census, after the last measured pose's reading, attached to that pose.
  let censusDone = censusMode !== 'final' && glMode === 'every' && vmmapMode === 'every';
  const finalCensus = async () => {
    if (censusDone) return;
    censusDone = true;
    const row = report.snapshots.at(-1);
    if (!row) return;
    if (vmmapMode === 'last') {
      try { writeFileSync(row.native.vmmapPath, execFileSync('vmmap', ['-summary', String(gamePID)], { encoding: 'utf8', timeout: 30000, maxBuffer: 8e6 })); }
      catch (error) { row.native.vmmapError = String(error); }
    }
    if (glMode === 'last') {
      row.light = await evaluate(lightExpression);
      row.glBytes = row.light.gl.reduce((sum, context) => sum + context.totalBytes, 0);
      row.glReadAfterAllReadings = true;
      if (row.light.settings?.memorySaver !== memorySaver) throw new Error('Memory saver fixture did not activate: expected ' + memorySaver + ', observed ' + row.light.settings?.memorySaver);
      save(); console.log(row.label, 'GL (read after the last footprint)', row.glBytes / 1e6);
    }
    if (censusMode !== 'final') return;
    report.stage = 'census:' + row.label; save();
    const value = await evaluate(snapshotExpression);
    const censusGL = value.census.gl.reduce((sum, context) => sum + context.totalBytes, 0);
    Object.assign(row, value, { censusAfterReading: true, censusGLDriftBytes: censusGL - row.glBytes });
    save(); console.log(row.label, 'census GL', censusGL / 1e6, 'model', value.residency.cost.playing / 1e6);
  };

  await evaluate(`(()=>{const resume=[...document.querySelectorAll('button')].find(b=>b.textContent.trim().toLowerCase()==='resume');if(!resume)throw new Error('Missing real recovery Resume button');resume.click();return true;})()`);
  await until("!window.__wildshard.requireWorld().hud.paused");
  const state=await evaluate('window.__wildshard.shard.grid.state()');
  if(state.home!=='driftwood-isle'||state.live.live.current!==null)throw new Error('Expected cold road recovery');
  report.initial=state;
  if(state.live.live.residents.includes('driftwood-isle'))throw new Error('DW already admitted before measurement');
  await evaluate(`(()=>{window.__g258FrameCallback=null;window.__g258ObserverStop=window.__wildshard.world.game.watchFrames(dt=>window.__g258FrameCallback?.(dt));window.__g258WatchFrames=fn=>{window.__g258FrameCallback=fn;return ()=>{if(window.__g258FrameCallback===fn)window.__g258FrameCallback=null;};};return true;})()`);
  const page={evaluate:expression=>evaluate(expression.replaceAll('world.game.watchFrames','window.__g258WatchFrames'),180000)};
  const before=await evaluate('window.__wildshard.shard.grid.state()');
  if(before.live.live.residents.includes('driftwood-isle'))throw new Error('DW admitted at the cold road');
  report.preEntry=before;save();
  await snapshot('dw-cold-road');
  const drive=async(name,from,to,points)=>{
    report.stage='route:'+name;writeFileSync(phaseFile,report.stage);save();
    const result=await runFloorGridRoute(page,{name,from,to,movement:'road-hover',waypoints:points,requiredResidents:to===null?[]:[to]},documentOrigin);
    report.routes.push(result);save();
    const failures=gridFloorWitnessFailures(result);if(failures.length)throw new Error(failures.join('; '));
  };
  await drive('dw-first-entry',null,'driftwood-isle',[{x:277.5,z:832.5},{x:277.5,z:277.5},{x:0,z:277.5},{x:0,z:210}]);
  await snapshot('dw-entry');
  await drive('dw-centre','driftwood-isle','driftwood-isle',[{x:0,z:100},{x:0,z:0}]);
  for(let i=0;i<12;i++){await evaluate('(window.__wildshard.requireWorld().player.yaw+=Math.PI/6,true)');await sleep(100);}
  await snapshot('dw-centre');
  report.finalErrors=await evaluate('window.__g227Errors');
  if(report.finalErrors.length)throw new Error('Game errors: '+JSON.stringify(report.finalErrors));
  await finalCensus();
  }
} catch (error) { report.diagnostic = await inspector?.raw(`JSON.stringify({url:location.href,origin:performance.timeOrigin,token:window.__frameFloorGridDocumentToken,stop:window.__frameFloorGridStop,grid:window.__wildshard?.shard?.grid?.state(),player:window.__wildshard?.world?.player?.position,body:document.body.innerText.slice(-4000),loading:document.querySelector('.ws-load')?.textContent,saved:(()=>{try{const keys=JSON.parse(localStorage.getItem('wildshard.save.v2.device')??'{"keys":{}}').keys;return Object.fromEntries(['life.lastEnd','life.lastUnload','boot.trace'].map(k=>[k,keys?.[k]?.data??null]));}catch(error){return{error:String(error)};}})()})`).catch(() => null); report.failure = String(error); process.exitCode = 1; console.error(report.failure); }
finally {
  report.errors = await inspector?.raw('JSON.stringify(window.__g227Errors ?? [])').catch(() => null);
  report.warnings = await inspector?.raw('JSON.stringify(window.__g227Warnings ?? [])').catch(() => null);
  inspector?.close(); proxy?.kill('SIGTERM'); writeFileSync(phaseFile, 'done');
  if (sampler) { await Promise.race([new Promise(resolve => sampler.once('exit', resolve)), sleep(3000)]); if (sampler.exitCode === null) sampler.kill('SIGTERM'); }
  try { simctl(['terminate', udid, 'com.apple.mobilesafari']); } catch { /* Already exited. */ }
  report.closed = true; save();
}

function evaluator(raw, observe = () => undefined) {
  return async (expression, timeout = 35000) => {
    const key = `__frameFloorEval${++evalSequence}`;
    const origin = await raw(`globalThis.__g227DocumentToken ??= crypto.randomUUID(); globalThis[${JSON.stringify(key)}] = {done:false}; Promise.resolve().then(() => (${expression})).then(value => {globalThis[${JSON.stringify(key)}] = {done:true,value};}, error => {globalThis[${JSON.stringify(key)}] = {done:true,error:String(error)};}); JSON.stringify({timeOrigin:performance.timeOrigin,token:globalThis.__g227DocumentToken})`);
    const identity = JSON.parse(origin);
    const start = Date.now();
    try {
      while (Date.now() - start < timeout) {
        const value = await raw(`JSON.stringify({origin:performance.timeOrigin,token:globalThis.__g227DocumentToken,state:globalThis[${JSON.stringify(key)}] ?? null,progress:window.__frameFloorGridProgress?.() ?? null})`);
        const envelope = typeof value === 'string' ? JSON.parse(value) : null;
        if (envelope?.token !== identity.token) throw Object.assign(new Error('Frame floor document changed during evaluation (navigation or graphics recovery); measurement cannot continue'), { documentOrigin: envelope?.origin });
        report.evaluationOriginDriftMaxMs = Math.max(report.evaluationOriginDriftMaxMs ?? 0, Math.abs(envelope.origin - identity.timeOrigin));
        if (envelope.progress) observe(envelope.progress);
        const state = envelope.state;
        if (state?.done) { if (state.error) throw new Error(state.error); return state.value; }
        await sleep(100);
      }
      throw new Error(`Browser evaluation timed out: ${expression.slice(0, 80)}`);
    } finally { await raw(`delete globalThis[${JSON.stringify(key)}]`).catch(() => { /* A navigated page may have dropped the evaluation envelope. */ }); }
  };
}
function webkit(wsUrl) {
  const ws = new WebSocket(wsUrl, { maxPayload: 512 * 1024 * 1024 }), pending = new Map(), listeners = new Map();
  let seq = 0, target = null;
  const opened = new Promise((resolve, reject) => { ws.addEventListener('open', resolve, { once: true }); ws.addEventListener('error', reject, { once: true }); });
  ws.addEventListener('close', event => { for (const [id, waiter] of pending) { clearTimeout(waiter.timer); waiter.reject(new Error(`Inspector socket closed ${event.code}: ${event.reason}`)); pending.delete(id); } });
  const inner = (message) => {
    for (const listener of listeners.get(message.method) ?? []) listener(message.params);
    const waiter = pending.get(message.id);
    if (waiter) { pending.delete(message.id); clearTimeout(waiter.timer); if (message.error) waiter.reject(new Error(message.error.message)); else waiter.done(message.result); }
  };
  ws.addEventListener('message', (event) => {
    const message = JSON.parse(String(event.data));
    if (message.method === 'Target.targetCreated' && message.params.targetInfo.type === 'page') target = message.params.targetInfo.targetId;
    else if (message.method === 'Target.didCommitProvisionalTarget') target = message.params.newTargetId;
    else if (message.method === 'Target.dispatchMessageFromTarget') inner(JSON.parse(message.params.message));
    else inner(message);
  });
  const send = (method, params = {}) => new Promise((resolve, reject) => {
    const id = ++seq;
    const timer = setTimeout(() => { pending.delete(id); reject(new Error(`Web Inspector timed out: ${method}`)); }, method === 'Heap.snapshot' ? 300000 : 10000);
    pending.set(id, { done: resolve, reject, timer });
    const message = { id, method, params };
    ws.send(JSON.stringify(target ? { id: ++seq, method: 'Target.sendMessageToTarget', params: { targetId: target, message: JSON.stringify(message) } } : message));
  });
  return { opened, send, on: (method, listener) => { const entries = listeners.get(method) ?? new Set(); entries.add(listener); listeners.set(method, entries); return () => { entries.delete(listener); if (entries.size === 0) listeners.delete(method); }; }, raw: async (expression) => {
    const result = await send('Runtime.evaluate', { expression, returnByValue: true });
    if (result.wasThrown) throw new Error(result.result?.description ?? 'Safari evaluation threw');
    return result.result?.value;
  }, close: () => { for (const p of pending.values()) { clearTimeout(p.timer); p.reject(new Error('Inspector closed')); } pending.clear(); listeners.clear(); ws.close(); } };
}
async function safariPage(base) {
  const start = Date.now();
  while (Date.now() - start < 20000) {
    for (let port = 9232; port <= 9240; port++) {
      try {
        const pages = await (await fetch(`http://127.0.0.1:${port}/json`, { signal: AbortSignal.timeout(500) })).json();
        const page = pages.find((p) => p.url?.startsWith(base));
        if (page) return page.webSocketDebuggerUrl;
      } catch { /* Proxy discovery has not announced the Simulator yet. */ }
    }
    await sleep(200);
  }
  throw new Error('Simulator Safari page not exposed by ios_webkit_debug_proxy (ports 9232–9240)');
}

async function footprintControl(evaluate) {
  // A separate offscreen allocation experiment, after all measured route poses.
  // Compare the same WebContent PID and the separately sampled GPU process, then delete everything.
  const controlSample = async label => {
    writeFileSync(phaseFile, label); await sleep(3000);
    const samples = [];
    for (let i = 0; i < 3; i++) {
      await sleep(1100);
      const rows = readFileSync(nativeFile, 'utf8').split('\n').filter(Boolean).map(line => JSON.parse(line));
      const latest = rows.findLast(row => row.type === 'sample' && row.phase === label);
      const [pid, values] = Object.entries(latest.pids).sort((a,b) => b[1][0] - a[1][0])[0];
      samples.push({pid:Number(pid),webContentBytes:values[0],gpuProcessBytes:latest.gpu});
    }
    return { samples, webContentBytes: samples.map(s=>s.webContentBytes).sort((a,b)=>a-b)[1],
      gpuProcessBytes: samples.map(s=>s.gpuProcessBytes).sort((a,b)=>a-b)[1] };
  };
  const result = {protocol:'After route poses, a separate offscreen RGBA8 4096x4096 texture (67,108,864 bytes), full-surface shader draw/finished, then deleted. No texture CPU upload. WC and GPU-process physical footprints sampled independently.'};
  result.before = await controlSample('gl-control-before'); 
  result.allocatedBytes = await evaluate(`(() => {
    const canvas = document.createElement('canvas'), gl = canvas.getContext('webgl2');
    if (!gl) throw new Error('No WebGL2 control context');
    const texture = gl.createTexture(), framebuffer = gl.createFramebuffer();
    gl.bindTexture(gl.TEXTURE_2D,texture); gl.texStorage2D(gl.TEXTURE_2D,1,gl.RGBA8,4096,4096);
    gl.bindFramebuffer(gl.FRAMEBUFFER,framebuffer); gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,texture,0);
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) throw new Error('Incomplete GL control allocation');
    const shader = (type, source) => { const s=gl.createShader(type); gl.shaderSource(s,source); gl.compileShader(s); if (!gl.getShaderParameter(s,gl.COMPILE_STATUS)) throw new Error('Control shader failed'); return s; };
    const vertex=shader(gl.VERTEX_SHADER,'#version 300 es\\nvoid main(){vec2 p=vec2((gl_VertexID<<1)&2,gl_VertexID&2);gl_Position=vec4(p*2.0-1.0,0,1);}');
    const fragment=shader(gl.FRAGMENT_SHADER,'#version 300 es\\nprecision highp float;out vec4 colour;void main(){colour=vec4(fract(gl_FragCoord.x*.017),fract(gl_FragCoord.y*.021),fract(gl_FragCoord.x*gl_FragCoord.y*.003),1);}');
    const program=gl.createProgram();gl.attachShader(program,vertex);gl.attachShader(program,fragment);gl.linkProgram(program);
    if (!gl.getProgramParameter(program,gl.LINK_STATUS)) throw new Error('Control program failed');
    gl.useProgram(program);gl.viewport(0,0,4096,4096);gl.drawArrays(gl.TRIANGLES,0,3);gl.finish();
    gl.deleteProgram(program);gl.deleteShader(vertex);gl.deleteShader(fragment);
    const pixel=new Uint8Array(4);gl.readPixels(1777,1555,1,1,gl.RGBA,gl.UNSIGNED_BYTE,pixel);window.__g227ControlPixel=[...pixel];
    if (gl.getError() !== gl.NO_ERROR) throw new Error('GL control allocation failed');
    window.__g227GLControl = {canvas,gl,texture,framebuffer}; return 4096*4096*4;
  })()`);
  result.during = await controlSample('gl-control-during');
  result.pixel = await evaluate('window.__g227ControlPixel');
  await evaluate('(() => { const bytes=new Uint8Array(67108864);for(let i=0;i<bytes.length;i+=4096)bytes[i]=1;window.__g227CPUControl=bytes;return bytes.length;})()');
  result.cpuPositive = await controlSample('cpu-control-positive');
  await evaluate('(delete window.__g227CPUControl,true)'); 
  await evaluate(`(() => { const {gl,texture,framebuffer}=window.__g227GLControl; gl.deleteFramebuffer(framebuffer); gl.deleteTexture(texture); gl.finish(); gl.getExtension('WEBGL_lose_context')?.loseContext(); delete window.__g227GLControl; return true;})()`);
  result.after = await controlSample('gl-control-after'); 
  return result;
}
