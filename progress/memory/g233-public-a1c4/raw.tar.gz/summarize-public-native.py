from pathlib import Path
import json,statistics,hashlib,gzip,subprocess
s=Path('/private/tmp/claude-501/sp-builders/sp-x4'); attempts=json.loads((s/'public-native-attempts.json').read_text()); valid=[a for a in attempts if a['status']=='valid'];assert len(valid)==3
labels=['home-settled','public-road','public-template-centre'];rows=[];observations=[]
for a in attempts:
 d=json.loads(Path(a['out']).read_text())
 for p in d.get('snapshots',[]):
  wc=p['native']['medianBytes'];gl=sum(g['totalBytes']for g in p['census']['gl']);observations.append({'attempt':a['number'],'attemptStatus':a['status'],'pose':p['label'],'webContentBytes':wc,'labelledGlBytes':gl,'combinedBytes':wc+gl,'highSampleCombinedBytes':max(x['footprintBytes']for x in p['native']['samples'])+gl,'timestamps':[x['at']for x in p['native']['samples']]})
for label in labels:
 samples=[r for r in observations if r['attemptStatus']=='valid'and r['pose']==label];assert len(samples)==3
 row={'pose':label,'coldRuns':samples}
 for key in ['webContentBytes','labelledGlBytes','combinedBytes','highSampleCombinedBytes']:
  vs=[r[key]for r in samples];row[key]={'median':statistics.median(vs),'min':min(vs),'max':max(vs),'spread':max(vs)-min(vs)}
 rows.append(row)
summary={'label':'public grid as it would ship once GRID_GATES_PASSED flips','pin':json.loads((s/'public-native-manifest.json').read_text())['pin'],'validColdRuns':len(valid),'failedColdAttempts':len(attempts)-len(valid),'attempts':attempts,'poses':rows,'allObservedPosesIncludingFailedAttempts':observations,'worstValidSampleCombinedBytes':max(r['highSampleCombinedBytes']for r in observations if r['attemptStatus']=='valid'),'worstObservedSampleCombinedBytesIncludingFailedAttempts':max(r['highSampleCombinedBytes']for r in observations),'configuration':{'developer':False,'memorySaver':'off','tier':'phone','dpr':2,'muted':True},'limitation':'Settled Simulator WebContent physical footprint plus labelled GL at home/road/template. Not a loading/transient peak or a physical-iPhone cap reading. Failed attempts and their completed pose samples remain visible; no values are subtracted or replaced.'}
(s/'public-native-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'valid':len(valid),'failed':len(attempts)-len(valid),'poses':[{k:r[k]for k in['pose','combinedBytes','highSampleCombinedBytes']}for r in rows],'worstAll':summary['worstObservedSampleCombinedBytesIncludingFailedAttempts']},indent=2))
