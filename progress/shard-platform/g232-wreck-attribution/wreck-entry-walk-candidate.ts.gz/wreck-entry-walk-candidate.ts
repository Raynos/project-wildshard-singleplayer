import { expect, it } from 'vitest';
import { Scope } from '../../../src/engine/app/scope';
import { withOwner } from '../../../src/engine/app/ownership';
import { Physics } from '../../../src/engine/physics/Physics';
import { CharacterMotor } from '../../../src/engine/physics/CharacterMotor';
import { castRay } from '../../../src/engine/physics/query';
import { addPiece } from '../../../src/engine/physics/pieces';
import { addTerrain } from '../../../src/engine/physics/terrain';
import { loadRapier } from '../../../src/engine/physics/rapier';
import { setTerrainHeight } from '../../../src/engine/world/terrainHeight';
import { configureLevel } from '../../../src/engine/level/selection';
import { toLevelSpec } from '../../../src/game/shard/spec';
import manifest, { WRECK, JETTIES } from '../../../src/shards/driftwood-isle/manifest';
import { Wreck } from '../../../src/shards/driftwood-isle/world/Wreck';
import { Pier } from '../../../src/shards/driftwood-isle/world/Pier';
import { G164_LOWERED } from '../../../src/shards/driftwood-isle/world/build';
import { fakeWorld } from '../../fake/world';
import wasmInline from '@dimforge/rapier3d-simd/rapier_wasm3d_bg.wasm?inline';
it.each([-1, 1])('walks the actual wreck entry in direction %i with drawn reef-rock collision', async direction => {
 const terrain=manifest.ground.terrain,jetty=JETTIES[2];if(terrain===undefined||jetty===undefined)throw Error('terrain/jetty');
 configureLevel(toLevelSpec(manifest));setTerrainHeight(terrain.heightAt);
 const scope=new Scope('wreck-diagnostic'),physics=new Physics(await loadRapier(await (await fetch(wasmInline)).arrayBuffer()));
 const wreck=withOwner(scope,()=>new Wreck(fakeWorld().sky,WRECK).build());
 const {pierStart:cut,level,seaRamp}=G164_LOWERED;
 const pier=withOwner(scope,()=>new Pier(fakeWorld().sky,{x:jetty.x+Math.sin(jetty.rot)*cut,z:0,rot:jetty.rot,length:jetty.length-cut,width:3,deckY:level+1.2,landing:jetty.landing??false,seaRamp}).build());
 if(pier.placed===null)throw Error('pier');
 addTerrain(physics);const built=addPiece(physics,{id:'wreck',name:'Wreck',category:'props',file:'fixture',colliders:wreck.colliderDescs()});
 addPiece(physics,{id:'jetty',name:'Jetty',category:'props',file:'fixture',colliders:[...pier.placed.colliders]});
 const motor=new CharacterMotor(physics,{radius:.38,height:1.8,step:.35,maxClimbDeg:40,snap:.3,group:'PLAYER',blockedBy:['WORLD']});
 const target=direction===-1?120:230;
 const feet={x:direction===-1?230:120,y:terrain.heightAt(direction===-1?230:120,0),z:0};let vy=0;
 physics.step();const landed=castRay(physics,{x:feet.x,y:feet.y+2.5,z:0},{x:0,y:-1,z:0},2.6);if(landed!==null)feet.y=Math.max(feet.y,landed.point.y);
 try{for(let tick=0;tick<1800;tick++){physics.step();vy-=22/60;const dx=target-feet.x,dz=-feet.z,d=Math.hypot(dx,dz);if(d<.8)break;const moved=motor.move(feet,{x:dx/d*4.3/60,y:vy/60,z:dz/d*4.3/60});if(moved.grounded&&vy<0)vy=0;}
 const contacts: object[]=[];motor.touching(.05,['WORLD'],c=>{contacts.push({index:built.colliders.findIndex(v=>v.handle===c.handle),shape:c.shape.type,translation:c.translation()});return true;});
 const hit=castRay(physics,{x:feet.x,y:feet.y+.7,z:feet.z},{x:direction,y:0,z:0},3);
 expect(Math.hypot(feet.x-target,feet.z)<.8,JSON.stringify({feet,contacts,hit:hit===null?null:{point:hit.point,normal:hit.normal,shape:hit.collider.shape}})).toBe(true);
 }finally{motor.dispose();physics.dispose();scope.dispose();setTerrainHeight(()=>0);}
});
